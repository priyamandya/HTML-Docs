
document.getElementById("demo").innerHTML="hi how are yoou";