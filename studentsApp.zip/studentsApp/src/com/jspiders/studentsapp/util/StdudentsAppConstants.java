package com.jspiders.studentsapp.util;

import java.util.HashMap;

public interface StdudentsAppConstants {

}
